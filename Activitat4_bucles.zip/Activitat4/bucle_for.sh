#!/bin/bash

archivo="Act3_parole.txt"

if [ ! -f "$archivo" ]; then
	echo "El archivo $archivo no existe"
	exit 1
fi

tmp="${archivo}.tmp"
> "$tmp"

IFS=$'\n'
for linia in $(cat "$archivo")
do
	limpio="${linia%%\#*}"
	echo "$limpio" >> "$tmp"
done

mv "$tmp" "$archivo"
echo "Comentarios eliminados correctamente"


read -p "Introduce la palabra que quieras buscar: " busqueda
encontrado=0

for linia in $(cat "$archivo")
do
	case "$linia" in
		*"$busqueda"*)
		encontrado=1
		;;
	esac
done

if [ $encontrado  -eq 1 ]; then
	echo "La palabra existe"
else
	echo "La palabra no existe"
fi

frase=""

for intent in 1 2 3 4 5 6 7 8 9 10; do
    read -p "Introduce una frase final(obligatorio):" frase
    if [ -n "$frase" ]; then
	break
    fi
done

echo "$frase" >> "$archivo"
echo "la frase se ha introducido correctamente"
