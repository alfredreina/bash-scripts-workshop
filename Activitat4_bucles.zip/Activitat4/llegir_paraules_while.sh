#!/bin/bash
if [ -z "$1" ]; then
    echo "Has d'indicar un fitxer on guardar les paraules."
    exit 1
fi

fitxer="$1"

echo "Introdueix paraules. Escriu :> per acabar."

while true; do
    read -r paraula
    if [ "$paraula" = ":>" ]; then
        break
    fi
    echo "$paraula" >> "$fitxer"
done

echo "Paraules guardades a $fitxer"

