#!/bin/bash

valors=()
count=0

until [ $count -eq 3 ]; do
    read -p "Introdueix un valor numèric: " num

    if [[ "$num" =~ ^-?[0-9]+$ ]]; then
        valors+=("$num")
        ((count++))
    else
        echo "Error: no és un nombre vàlid."
    fi
done

suma=$((valors[0] + valors[1] + valors[2]))
producte=$((valors[0] * valors[1] * valors[2]))

max=$((valors[0]))
min=$((valors[0]))

for n in "${valors[@]}"; do
    if [ $n -gt $max ]; then max=$n; fi
    if [ $n -lt $min ]; then min=$n; fi
done

echo "Suma: $suma"
echo "Producte: $producte"
echo "Màxim: $max"
echo "Mínim: $min"

