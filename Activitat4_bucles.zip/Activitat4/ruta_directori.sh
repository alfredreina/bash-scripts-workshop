++#!/bin/bash

until [ -d "$directori" ]; do
    read -p "Introdueix la ruta d'un directori: " directori
    if [ ! -d "$directori" ]; then
        echo "Error: la ruta no és un directori vàlid."
    fi
done

echo "Permisos del directori: $(ls -ld "$directori" | awk '{print $1}')"
echo
num_arxius=$(find "$directori" -maxdepth 1 -type f | wc -l)
echo "Nombre d'arxius: $num_arxius"
echo
num_carpetes=$(find "$directori" -maxdepth 1 -type d | wc -l)
echo "Nombre de carpetes: $((num_carpetes - 1))"
echo
echo "Arxius:"
find "$directori" -maxdepth 1 -type f -exec basename {} \;
echo
echo "Carpetes:"
find "$directori" -maxdepth 1 -type d -exec basename {} \; | grep -v "^$(basename "$directori")$"
