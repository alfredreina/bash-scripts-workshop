#!/bin/bash

opcions=("pedra" "paper" "tisores")

echo "Benvingut al joc Pedra, Paper o Tisores!"

while true; do
    read -p "Tria pedra, paper o tisores (o 'sortir' per acabar): " jugador
    jugador=$(echo "$jugador" | tr '[:upper:]' '[:lower:]')

    if [ "$jugador" == "sortir" ]; then
        echo "Fins aviat!"
        break
    fi

    if [[ ! " ${opcions[@]} " =~ " $jugador " ]]; then
        echo "Tria no vàlida. Torna-ho a provar."
        continue
    fi

    maquina=${opcions[$RANDOM % 3]}
    echo "La màquina ha triat: $maquina"

    if [ "$jugador" == "$maquina" ]; then
        echo "Empat!"
    elif { [ "$jugador" == "pedra" ] && [ "$maquina" == "tisores" ]; } || \
         { [ "$jugador" == "paper" ] && [ "$maquina" == "pedra" ]; } || \
         { [ "$jugador" == "tisores" ] && [ "$maquina" == "paper" ]; }; then
        echo "Has guanyat!"
    else
        echo "Has perdut!"
    fi

    echo
done
