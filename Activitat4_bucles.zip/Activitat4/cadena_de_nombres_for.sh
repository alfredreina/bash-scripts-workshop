#!/bin/bash

positius=0
negatius=0
zeros=0

for num in "$@"; do
    if [[ "$num" =~ ^-?[0-9]+$ ]]; then
        if (( num > 0 )); then
            (( positius++ ))
        elif (( num < 0 )); then
            (( negatius++ ))
        else
            (( zeros++ ))
        fi
    else
        echo "Valor no vàlid: $num"
    fi
done

echo "Positius: $positius"
echo "Negatius: $negatius"
echo "Zeros: $zeros"
