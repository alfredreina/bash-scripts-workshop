#!/bin/bash

url="https://agora.xtec.cat/ies-sabadell/"

until ping -c 1 agora.xtec.cat &>/dev/null; do
    echo "No hi ha connexió a Internet. Tornant a provar en 5 segons..."
    sleep 5
done

echo "Connexió establerta."
firefox "$url" &
