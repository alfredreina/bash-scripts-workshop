#!/bin/bash

usuaris_majus=$(cut -d: -f1 /etc/passwd | grep '[A-Z]')

echo "Usuaris amb alguna lletra majúscula al nom:"
echo "$usuaris_majus"
echo

read -p "Introdueix un nom d'usuari: " nom

while ! id "$nom" &>/dev/null; do
    echo "Error: l'usuari '$nom' no existeix."
    read -p "Torna a introduir un nom d'usuari: " nom
done

echo
echo "Informació de l'usuari '$nom':"
getent passwd "$nom"

