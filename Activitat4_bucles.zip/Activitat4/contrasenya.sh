#!/bin/bash

valida=false

while [ "$valida" = false ]; do
    read -s -p "Introdueix una contrasenya: " pass
    echo

    errors=""

    if [ ${#pass} -lt 8 ]; then
        errors+="Ha de tenir almenys 8 caràcters. "
    fi

    if [[ ! "$pass" =~ [A-Z] ]]; then
        errors+="Ha de contenir almenys una majúscula. "
    fi

    if [[ ! "$pass" =~ [0-9] ]]; then
        errors+="Ha de contenir almenys un número. "
    fi

    if [ -z "$errors" ]; then
        valida=true
        echo "Contrasenya vàlida."
    else
        echo "Error: $errors"
    fi
done

