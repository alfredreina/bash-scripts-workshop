#!/bin/bash

while true; do
    echo "1) Mostrar data i hora actual"
    echo "2) Comprovar si existeix un fitxer"
    echo "3) Sortir"
    read -p "Selecciona una opció: " opcio

    case $opcio in
        1)
            date
            ;;
        2)
            read -p "Introdueix el nom del fitxer: " fitxer
            if [ -e "$fitxer" ]; then
                echo "El fitxer existeix."
            else
                echo "El fitxer no existeix."
            fi
            ;;
        3)
            echo "Sortint..."
            break
            ;;
        *)
            echo "Opció no vàlida."
            ;;
    esac

    echo
done
